﻿Imports System.Data.OleDb

Public Class WebForm3
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label2.Text = Session("1").ToString()
        Image1.ImageUrl = Session("2").ToString()
        romet1()
        Label6.Text = GridView2.Rows.Count
        Label8.Text = GridView3.Rows.Count
        Label10.Text = GridView4.Rows.Count
        Label12.Text = GridView5.Rows.Count
        Label14.Text = GridView6.Rows.Count
    End Sub
    Sub romet1()
        Dim CariData As String = "SELECT * FROM admin WHERE nama ='" & Label5.Text & "'"
        Try
            Dim Conn As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb")
            Conn.Open()
            Dim cmdData As New OleDbCommand(CariData, Conn)
            Dim reader As OleDbDataReader = cmdData.ExecuteReader
            reader.Read()
            If reader.HasRows Then
                Label1.Text = reader("id")
                Label3.Text = reader("unittugas")
                Label4.Text = reader("jabatan")
                'Proses Cari Image Dengan Nilai byte
            End If
        Catch ex As Exception
            Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('buku yang anda pesan tidak tersedia');</script>")
        End Try
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub
    Protected Sub GridView2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView2.SelectedIndexChanged
        GridView2.FooterRow.Cells(0).Text = "Total = " & GridView2.Rows.Count.ToString()
    End Sub
    Protected Sub GridView3_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView3.SelectedIndexChanged
        GridView3.FooterRow.Cells(0).Text = "Total = " & GridView3.Rows.Count.ToString()
    End Sub
    Protected Sub GridView4_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView4.SelectedIndexChanged
        GridView4.FooterRow.Cells(0).Text = "Total = " & GridView4.Rows.Count.ToString()
    End Sub
    Protected Sub GridView5_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView5.SelectedIndexChanged
        GridView5.FooterRow.Cells(0).Text = "Total = " & GridView5.Rows.Count.ToString()
    End Sub
    Protected Sub GridView6_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView6.SelectedIndexChanged
        GridView6.FooterRow.Cells(0).Text = "Total = " & GridView6.Rows.Count.ToString()
    End Sub
End Class