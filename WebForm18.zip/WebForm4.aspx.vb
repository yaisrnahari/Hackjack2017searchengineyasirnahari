﻿Imports System.Data.OleDb
Imports System.IO

Public Class WebForm4
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If FileUpload1.HasFile Then
            Dim name As String = FileUpload1.PostedFile.FileName
            Dim length As Integer = FileUpload1.PostedFile.ContentLength

            Dim imageBytes As Byte() = New Byte(length - 1) {}
            Dim imageStream As Stream = FileUpload1.PostedFile.InputStream
            imageStream.Read(imageBytes, 0, length)
            Dim nameop As String = FileUpload2.PostedFile.FileName
            Dim lengthop As Integer = FileUpload2.PostedFile.ContentLength

            Dim imageBytesop As Byte() = New Byte(length - 1) {}
            Dim imageStreamop As Stream = FileUpload2.PostedFile.InputStream
            imageStreamop.Read(imageBytesop, 0, length)
            Dim connString As String = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb")
            Dim connection As New OleDbConnection(connString)

            Dim insertQuery As String = "INSERT INTO lembaga(id,nilek,namalembaga,jenislembaga,jalan,kecamatan,kotamadya,provinsi,lintang,bujur,tlpn,weblembaga,namapimpinan,namaoperator,alamatoperator,tlpnoperator,kunci,fotolembaga,foto) VALUES(@id,@nilek,@namalembaga,@jenislembaga,@jalan,@kecamatan,@kotamadya,@provinsi,@lintang,@bujur,@tlpn,@weblembaga,@namapimpinan,@namaoperator,@alamatoperator,@tlpnoperator,@kunci,@fotolembaga,@foto)"
            Dim command As New OleDbCommand()
            command.Connection = connection
            command.CommandText = insertQuery
            command.CommandType = CommandType.Text
            command.Parameters.AddWithValue("@id", TextBox1.Text)
            command.Parameters.AddWithValue("@nilek", TextBox11.Text)
            command.Parameters.AddWithValue("@namalembaga", TextBox2.Text)
            command.Parameters.AddWithValue("@jenislembaga", DropDownList1.SelectedItem.Text)
            command.Parameters.AddWithValue("@jalan", TextBox4.Text)
            command.Parameters.AddWithValue("@kecamatan", TextBox16.Text)
            command.Parameters.AddWithValue("@kotamadya", DropDownList3.SelectedItem.Text)
            command.Parameters.AddWithValue("@provinsi", TextBox5.Text)
            command.Parameters.AddWithValue("@lintang", TextBox6.Text)
            command.Parameters.AddWithValue("@bujur", TextBox7.Text)
            command.Parameters.AddWithValue("@tlpn", TextBox8.Text)
            command.Parameters.AddWithValue("@weblembaga", TextBox10.Text)
            command.Parameters.AddWithValue("@namapimpinan", TextBox9.Text)
            command.Parameters.AddWithValue("@namaoperator", TextBox12.Text)
            command.Parameters.AddWithValue("@alamatoperator", TextBox13.Text)
            command.Parameters.AddWithValue("@tlpnoperator", TextBox14.Text)
            command.Parameters.AddWithValue("@kunci", TextBox15.Text)
            command.Parameters.AddWithValue("@fotolembaga", imageBytes)
            command.Parameters.AddWithValue("@foto", imageBytesop)

            Try
                connection.Open()
                command.ExecuteNonQuery()
                Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('data telah sukses tersimpan');</script>")
            Catch ex As Exception
                Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('error check your connection');</script>")
            Finally
                connection.Close()
            End Try
        End If
    End Sub

    
    Protected Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        Button1.Enabled = True
    End Sub
End Class