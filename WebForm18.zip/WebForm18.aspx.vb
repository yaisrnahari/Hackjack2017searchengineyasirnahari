﻿Imports System.Data.OleDb

Public Class WebForm18
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ddlImages.DataSource = GetData1("SELECT Id, nama FROM admin")
        ddlImages.DataTextField = "nama"
        ddlImages.DataValueField = "id"
        ddlImages.DataBind()
    End Sub
    Private Function GetData1(query As String) As DataTable
        Dim dt As New DataTable()
        Dim constr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb"
        Using con As New OleDbConnection(constr)
            Using cmd As New OleDbCommand(query)
                Using sda As New OleDbDataAdapter()
                    cmd.CommandType = CommandType.Text
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    sda.Fill(dt)
                End Using
            End Using
            Return dt
        End Using
    End Function
    Protected Sub FetchImage(sender As Object, e As EventArgs) Handles ddlImages.SelectedIndexChanged
        Dim id As String = ddlImages.SelectedItem.Value
        Image1.Visible = id <> "0"
        If id <> "0" Then
            Dim bytes As Byte() = DirectCast(GetData1(Convert.ToString("SELECT foto FROM admin WHERE Id =") & id).Rows(0)("foto"), Byte())
            Dim base64String As String = Convert.ToBase64String(bytes, 0, bytes.Length)
            Image1.ImageUrl = Convert.ToString("data:image/png;base64,") & base64String
        End If
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Session("1") = ddlImages.SelectedItem.Text.ToString()
        Session("2") = Image1.ImageUrl.ToString()
        Dim connect As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb"
        Dim query As String
        query = "Select Count(*) From admin Where nama = ? And kunci = ?"
        Dim result As Integer = 0
        Using conn As New OleDbConnection(connect)
            Using cmd As New OleDbCommand(query, conn)
                cmd.Parameters.AddWithValue("", ddlImages.SelectedItem.Text)
                cmd.Parameters.AddWithValue("", TextBox1.Text)
                conn.Open()
                result = DirectCast(cmd.ExecuteScalar(), Integer)
            End Using
        End Using
        If result > 0 Then
            Response.Redirect("webform3.aspx")
        Else
            Label1.Visible = True
            Label1.Text = "Invalid credentials"
        End If
    End Sub
End Class