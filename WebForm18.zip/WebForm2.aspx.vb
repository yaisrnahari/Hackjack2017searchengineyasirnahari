﻿Imports System.Data.OleDb

Public Class WebForm2
    Inherits System.Web.UI.Page
    Protected keywords As New List(Of String)()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label2.Text = Session("1").ToString()

    End Sub

    Sub repeater()
        Dim Connection As OleDbConnection
        Connection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb")
        Connection.Open()
        Dim Command As OleDbCommand
        Command = New OleDbCommand("SELECT * FROM lembaga", Connection)
        Dim DataReader As OleDbDataReader
        DataReader = Command.ExecuteReader()
        RepeaterSearchResult.DataSource = DataReader
        Connection.Close()
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Turn user input to a list of keywords.
        Dim keywords As String() = TextBox1.Text.Split(New String() {" "}, StringSplitOptions.RemoveEmptyEntries)

        ' The basic validation.
        If keywords.Length <= 0 Then
            Label1.Text = "Please input keyword."
            Return
        End If
        Me.keywords = keywords.ToList()

        ' Do search operation.
       
    End Sub
End Class