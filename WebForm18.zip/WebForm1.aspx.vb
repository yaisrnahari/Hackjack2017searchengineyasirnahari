﻿Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected keywords As New List(Of String)()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim keywords As String() = TextBox1.Text.Split(New String() {" "}, StringSplitOptions.RemoveEmptyEntries)

        ' The basic validation.
        If keywords.Length <= 0 Then
            Label1.Text = "Please input keyword."
            Return
        End If
        Me.keywords = keywords.ToList()
        Session("1") = TextBox1.Text.ToString()
        TextBox1.Text = ""
        Response.Redirect("webform2.aspx")
    End Sub
End Class