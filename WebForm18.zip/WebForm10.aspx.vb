﻿Imports System.Data.OleDb

Public Class WebForm10
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label2.Text = Session("1").ToString()
        Label1.Text = Session("2").ToString()
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Connection As New OleDbConnection
        Connection = New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb")
        Connection.Open()
        Try
            Dim command As New OleDbCommand
            command = New OleDbCommand("INSERT INTO tentang(ID,nilek,namalembaga,jenislembaga,visilembaga,misilembaga,latarbelakanglembaga,programlembagasatu,programlembagadua,programlembagatiga,fasilitaslembaga) VALUES('" & TextBox1.Text & "','" & TextBox2.Text & "','" & Label2.Text & "','" & Label1.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & TextBox5.Text & "','" & TextBox6.Text & "','" & TextBox7.Text & "','" & TextBox8.Text & "','" & TextBox9.Text & "')", Connection)
            command.ExecuteNonQuery()
        Catch ex As Exception
        End Try
        Connection.Close()
        Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('data telah sukses tersimpan');</script>")
    End Sub
End Class