﻿Imports System.IO
Imports System.Data.OleDb

Public Class WebForm5
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If FileUpload1.HasFile Then
            Dim name As String = FileUpload1.PostedFile.FileName
            Dim length As Integer = FileUpload1.PostedFile.ContentLength

            Dim imageBytes As Byte() = New Byte(length - 1) {}
            Dim imageStream As Stream = FileUpload1.PostedFile.InputStream
            imageStream.Read(imageBytes, 0, length)

            Dim connString As String = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb")
            Dim connection As New OleDbConnection(connString)

            Dim insertQuery As String = "INSERT INTO admin(ID,nip,nama,unittugas,jabatan,alamat,notlpn,kunci,foto) VALUES(@ID,@nip,@nama,@unittugas,@jabatan,@alamat,@notlpn,@kunci,@foto)"
            Dim command As New OleDbCommand()
            command.Connection = connection
            command.CommandText = insertQuery
            command.CommandType = CommandType.Text
            command.Parameters.AddWithValue("@ID", TextBox1.Text)
            command.Parameters.AddWithValue("@nip", TextBox2.Text)
            command.Parameters.AddWithValue("@nama", TextBox3.Text)
            command.Parameters.AddWithValue("@unittugas", TextBox4.Text)
            command.Parameters.AddWithValue("@jabatan", TextBox5.Text)
            command.Parameters.AddWithValue("@alamat", TextBox6.Text)
            command.Parameters.AddWithValue("@notlpn", TextBox7.Text)
            command.Parameters.AddWithValue("@kunci", TextBox8.Text)
            command.Parameters.AddWithValue("@foto", imageBytes)

            Try
                connection.Open()
                command.ExecuteNonQuery()
                Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('data telah sukses tersimpan');</script>")
            Catch ex As Exception
                Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('error check your connection');</script>")
            Finally
                connection.Close()
            End Try
        End If
    End Sub
End Class