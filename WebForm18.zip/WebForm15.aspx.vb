﻿Imports System.Data.OleDb

Public Class WebForm15
    Inherits System.Web.UI.Page
    Protected Data As Article
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = Session("Data").ToString()

    End Sub
    
End Class