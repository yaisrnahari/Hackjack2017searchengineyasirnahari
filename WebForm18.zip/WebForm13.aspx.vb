﻿Imports System.Data.OleDb

Public Class WebForm13
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ddlImages.DataSource = GetData("SELECT Id, namaoperator FROM lembaga")
        ddlImages.DataTextField = "namaoperator"
        ddlImages.DataValueField = "id"
        ddlImages.DataBind()
        romet()
    End Sub
    Private Function GetData(query As String) As DataTable
        Dim dt As New DataTable()
        Dim constr As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb"
        Using con As New OleDbConnection(constr)
            Using cmd As New OleDbCommand(query)
                Using sda As New OleDbDataAdapter()
                    cmd.CommandType = CommandType.Text
                    cmd.Connection = con
                    sda.SelectCommand = cmd
                    sda.Fill(dt)
                End Using
            End Using
            Return dt
        End Using
    End Function
    Protected Sub FetchImage(sender As Object, e As EventArgs) Handles ddlImages.SelectedIndexChanged
        Dim id As String = ddlImages.SelectedItem.Value
        Image1.Visible = id <> "0"
        If id <> "0" Then
            Dim bytes As Byte() = DirectCast(GetData(Convert.ToString("SELECT foto FROM lembaga WHERE Id =") & id).Rows(0)("foto"), Byte())
            Dim base64String As String = Convert.ToBase64String(bytes, 0, bytes.Length)
            Image1.ImageUrl = Convert.ToString("data:image/png;base64,") & base64String
        End If
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Session("1") = ddlImages.SelectedItem.Text.ToString()
        Session("2") = Label1.Text.ToString()
        Session("3") = Image1.ImageUrl.ToString()
        Dim connect As String = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb"
        Dim query As String
        query = "Select Count(*) From lembaga Where namaoperator = ? And kunci = ?"
        Dim result As Integer = 0
        Using conn As New OleDbConnection(connect)
            Using cmd As New OleDbCommand(query, conn)
                cmd.Parameters.AddWithValue("", ddlImages.SelectedItem.Text)
                cmd.Parameters.AddWithValue("", TextBox7.Text)
                conn.Open()
                result = DirectCast(cmd.ExecuteScalar(), Integer)
            End Using
        End Using
        If result > 0 Then
            Response.Redirect("webform9.aspx")
        Else
            Label2.Visible = True
            Label2.Text = "Invalid credentials"
        End If
    End Sub
    Sub romet()
        Dim CariData As String = "SELECT * FROM lembaga WHERE namaoperator ='" & ddlImages.SelectedItem.Text & "'"
        Try
            Dim Conn As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb")
            Conn.Open()
            Dim cmdData As New OleDbCommand(CariData, Conn)
            Dim reader As OleDbDataReader = cmdData.ExecuteReader
            reader.Read()
            If reader.HasRows Then
                Label1.Text = reader("nilek")
                'Proses Cari Image Dengan Nilai byte
            End If
        Catch ex As Exception
            Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('Kesalahan dalam transaksi data');</script>")
        End Try
    End Sub
End Class