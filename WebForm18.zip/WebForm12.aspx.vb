﻿Imports System.Data.OleDb
Imports System.IO

Public Class WebForm12
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        TextBox3.Text = Session("1").ToString()
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If FileUpload1.HasFile Then
            Dim name As String = FileUpload1.PostedFile.FileName
            Dim length As Integer = FileUpload1.PostedFile.ContentLength

            Dim imageBytes As Byte() = New Byte(length - 1) {}
            Dim imageStream As Stream = FileUpload1.PostedFile.InputStream
            imageStream.Read(imageBytes, 0, length)

            Dim connString As String = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb")
            Dim connection As New OleDbConnection(connString)

            Dim insertQuery As String = "INSERT INTO galerry(id,nilek,namalembaga,tagline,tanggal,foto) VALUES(id,nilek,namalembaga,tagline,tanggal,foto)"
            Dim command As New OleDbCommand()
            command.Connection = connection
            command.CommandText = insertQuery
            command.CommandType = CommandType.Text
            command.Parameters.AddWithValue("@id", TextBox1.Text)
            command.Parameters.AddWithValue("@nilek", TextBox2.Text)
            command.Parameters.AddWithValue("@namalembaga", TextBox3.Text)
            command.Parameters.AddWithValue("@tagline", TextBox4.Text)
            command.Parameters.AddWithValue("@tanggal", TextBox5.Text)
            command.Parameters.AddWithValue("@foto", imageBytes)

            Try
                connection.Open()
                command.ExecuteNonQuery()
                Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('data telah sukses tersimpan');</script>")
            Catch ex As Exception
                Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('error check your connection');</script>")
            Finally
                connection.Close()
            End Try
        End If
    End Sub
End Class