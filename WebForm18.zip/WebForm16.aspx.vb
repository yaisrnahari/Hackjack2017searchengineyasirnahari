﻿Public Class WebForm16
    Inherits System.Web.UI.Page
    Protected keywords As New List(Of String)()
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label2.Text = Session("1").ToString()
    End Sub
    Protected Sub Viewsd(sender As Object, e As EventArgs)
        Session("Data") = (TryCast(sender, LinkButton)).Text
        Response.Redirect("webform21.aspx")
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        
    End Sub

End Class