﻿Imports System.Data.OleDb

Public Class WebForm21
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label1.Text = Session("Data").ToString()
        romet1()
        tentang()
    End Sub
    Sub romet1()
        Dim CariData As String = "SELECT * FROM lembaga WHERE namalembaga ='" & Label1.Text & "'"
        Try
            Dim Conn As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb")
            Conn.Open()
            Dim cmdData As New OleDbCommand(CariData, Conn)
            Dim reader As OleDbDataReader = cmdData.ExecuteReader
            reader.Read()
            If reader.HasRows Then
                Label9.Text = reader("jalan")
                Label10.Text = reader("kecamatan")
                Label11.Text = reader("kotamadya")
                Label12.Text = reader("weblembaga")
                Label13.Text = reader("tlpn")
                'Proses Cari Image Dengan Nilai byte
            End If
        Catch ex As Exception
            Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('buku yang anda pesan tidak tersedia');</script>")
        End Try
    End Sub
    Sub tentang()
        Dim CariData As String = "SELECT * FROM tentang WHERE namalembaga ='" & Label1.Text & "'"
        Try
            Dim Conn As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb")
            Conn.Open()
            Dim cmdData As New OleDbCommand(CariData, Conn)
            Dim reader As OleDbDataReader = cmdData.ExecuteReader
            reader.Read()
            If reader.HasRows Then
                Label2.Text = reader("visilembaga")
                Label3.Text = reader("misilembaga")
                Label4.Text = reader("latarbelakang")
                Label5.Text = reader("programlembagasatu")
                Label6.Text = reader("programlembagadua")
                Label7.Text = reader("programlembagatiga")
                Label8.Text = reader("fasilitaslembaga")
                'Proses Cari Image Dengan Nilai byte
            End If
        Catch ex As Exception
            Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('buku yang anda pesan tidak tersedia');</script>")
        End Try
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub
End Class