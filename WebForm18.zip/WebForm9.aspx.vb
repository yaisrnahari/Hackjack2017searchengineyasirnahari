﻿Imports System.Data.OleDb

Public Class WebForm9
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Label5.Text = Session("1").ToString()
        Label4.Text = Session("2").ToString()
        Image1.ImageUrl = Session("3").ToString()
        romet()
        Label9.Text = Label6.Text
        Label8.Text = Label6.Text
        Label10.Text = Label6.Text
    End Sub
    Sub romet()
        Dim CariData As String = "SELECT * FROM lembaga WHERE nilek ='" & Label4.Text & "'"
        Try
            Dim Conn As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb")
            Conn.Open()
            Dim cmdData As New OleDbCommand(CariData, Conn)
            Dim reader As OleDbDataReader = cmdData.ExecuteReader
            reader.Read()
            If reader.HasRows Then
                Label3.Text = reader("namalembaga")
                Label6.Text = reader("namalembaga")
                Label7.Text = reader("jenislembaga")
                'Proses Cari Image Dengan Nilai byte
            End If
        Catch ex As Exception
            Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('Kesalahan dalam transaksi data');</script>")
        End Try
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Session("1") = Label6.Text.ToString()
        Session("2") = Label7.Text.ToString()
        Dim url As String = "webform10.aspx"
        Dim s As String = "window.open('" & url + "', 'popup_window', 'width=300,height=100,left=100,top=100,resizable=yes');"
        ClientScript.RegisterStartupScript(Me.GetType(), "script", s, True)
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Session("1") = Label6.Text.ToString()
        Dim url As String = "webform7.aspx"
        Dim s As String = "window.open('" & url + "', 'popup_window', 'width=300,height=100,left=100,top=100,resizable=yes');"
        ClientScript.RegisterStartupScript(Me.GetType(), "script", s, True)
    End Sub

    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim url As String = "webform8.aspx"
        Dim s As String = "window.open('" & url + "', 'popup_window', 'width=300,height=100,left=100,top=100,resizable=yes');"
        ClientScript.RegisterStartupScript(Me.GetType(), "script", s, True)
    End Sub

    Protected Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Session("1") = Label6.Text.ToString()
        Dim url As String = "webform11.aspx"
        Dim s As String = "window.open('" & url + "', 'popup_window', 'width=300,height=100,left=100,top=100,resizable=yes');"
        ClientScript.RegisterStartupScript(Me.GetType(), "script", s, True)
    End Sub

    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Session("1") = Label6.Text.ToString()
        Dim url As String = "webform12.aspx"
        Dim s As String = "window.open('" & url + "', 'popup_window', 'width=300,height=100,left=100,top=100,resizable=yes');"
        ClientScript.RegisterStartupScript(Me.GetType(), "script", s, True)
    End Sub
End Class