﻿Imports System.IO
Imports System.Data.OleDb

Public Class WebForm8
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If FileUpload1.HasFile Then
            Dim name As String = FileUpload1.PostedFile.FileName
            Dim length As Integer = FileUpload1.PostedFile.ContentLength

            Dim imageBytes As Byte() = New Byte(length - 1) {}
            Dim imageStream As Stream = FileUpload1.PostedFile.InputStream
            imageStream.Read(imageBytes, 0, length)

            Dim connString As String = ("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=|DataDirectory|\se\serchengine.mdb")
            Dim connection As New OleDbConnection(connString)

            Dim insertQuery As String = "INSERT INTO siswa(ID,nisn,nama,unitpkbm,layanan,tempatlahir,tanggallahir,alamat,notlpn,namaibu,namaayah,jenispenghasilan,penghasilan,foto) VALUES(@ID,@nisn,@nama,@unitpkbm,@layanan,@tempatlahir,@tanggallahir,@alamat,@notlpn,@namaibu,@namaayah,@jenispenghasilan,@penghasilan,@foto)"
            Dim command As New OleDbCommand()
            command.Connection = connection
            command.CommandText = insertQuery
            command.CommandType = CommandType.Text
            command.Parameters.AddWithValue("@ID", TextBox1.Text)
            command.Parameters.AddWithValue("@nisn", TextBox2.Text)
            command.Parameters.AddWithValue("@nama", TextBox3.Text)
            command.Parameters.AddWithValue("@unitpkbm", TextBox4.Text)
            command.Parameters.AddWithValue("@layanan", TextBox5.Text)
            command.Parameters.AddWithValue("@tempatlahir", TextBox6.Text)
            command.Parameters.AddWithValue("@tanggallahir", TextBox7.Text)
            command.Parameters.AddWithValue("@alamat", TextBox8.Text)
            command.Parameters.AddWithValue("@notlpn", TextBox9.Text)
            command.Parameters.AddWithValue("@namaibu", TextBox10.Text)
            command.Parameters.AddWithValue("@namaayah", TextBox11.Text)
            command.Parameters.AddWithValue("@jenispenghasilan", DropDownList1.SelectedItem.Text)
            command.Parameters.AddWithValue("@penghasilan", TextBox12.Text)
            command.Parameters.AddWithValue("@foto", imageBytes)

            Try
                connection.Open()
                command.ExecuteNonQuery()
                Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('data telah sukses tersimpan');</script>")
            Catch ex As Exception
                Me.Page.ClientScript.RegisterStartupScript(Me.GetType(), "clientScript", "<script>javascript:alert('error check your connection');</script>")
            Finally
                connection.Close()
            End Try
        End If
    End Sub
End Class